package com.ifsc.ctds;

public class PatoMadeira extends Pato {
	
	
		
		public void nadar() {
			// ele n�o nada
		}
		public void display2() {
			System.out.println("Oi, eu sou o pato de Madeira");
		}
		
		public void quack() {
			// ele nao emite som
		}
		
		public void voar() {
			//ele nao pode voar
		}
	


}
