package com.ifsc.ctds;

public class TestePato {

	public static void main(String[] args) {
		Pato patolino = new Pato();
		PatoReal patoreal = new PatoReal();
		PatoVermelho patovermelho = new PatoVermelho();
		PatoMadeira patomadeira = new PatoMadeira();
		PatoBorracha patoborracha = new PatoBorracha();
		
		
		patolino.Display();
		patolino.Quack();
		patolino.Nadar();
		patolino.Patao();
		patolino.Voar();
		
		System.out.println(" ---------------------------"
				+ "-------------------------------");
		patoreal.Display1();
		patoreal.Patao1();
		
		System.out.println(" --------------------------"
				+ "---------------------");
		patovermelho.Quack2();
		patovermelho.Patao2();
		
		System.out.println(" --------------------------"
				+ "---------------------");
		patomadeira.display2();
		patomadeira.quack();
		patomadeira.voar();
		
		System.out.println(" --------------------------"
				+ "---------------------");
		patoborracha.display();
		patoborracha.nadar();
		patoborracha.quack();
		patoborracha.voar();
	
		
		
		
		

	}

}
