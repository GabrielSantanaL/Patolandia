package com.ifsc.ctds;

public class PatoVoador extends Pato {
	
	public void PatoVoador() {
		System.out.println("Euuu estouu Voandoo!!");
	}
	

}
