package com.ifsc.ctds;

public class PatoBorracha extends Pato{
	
	public void nadar() {
		System.out.println("Estou boiando");
	}
	
	public void display() {
		System.out.println("Oi, eu sou um  pato de borracha");
	}
	
	public void quack() {
		System.out.println("quack, quack, quack");
	}
	public void voar() {
		// ele nao voa
	}
	


}
