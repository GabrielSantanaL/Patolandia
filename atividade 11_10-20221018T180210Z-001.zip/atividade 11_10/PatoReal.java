package com.ifsc.ctds;

public class PatoReal extends Pato {
	
	public PatoReal() {}
	
	public void Display1() {
		System.out.println("Oi, eu sou o pato Real");
		
	}
	
	public static void Patao1() {
		System.out.println(""
				+ "      	    	   	    ########              \r\n" + 
				"                          ######  ####            \r\n" + 
				"                          ######  ############    \r\n" + 
				"                          ##################      \r\n" + 
				"                            ########              \r\n" + 
				"                            ######                \r\n" + 
				"                            ######                \r\n" + 
				"                            ######                \r\n" + 
				"                            ########              \r\n" + 
				"                          ############            \r\n" + 
				"                        ##############            \r\n" + 
				"                      ##################          \r\n" + 
				"          ##############################          \r\n" + 
				"        ################################          \r\n" + 
				"        ################################          \r\n" + 
				"          ############################            \r\n" + 
				"                ####################              \r\n" + 
				"                    ####                          \r\n" + 
				"                    ########             ");
	
	}
	

}
