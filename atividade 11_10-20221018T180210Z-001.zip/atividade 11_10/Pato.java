package com.ifsc.ctds;

public class Pato {
	public static void Quack () {
			System.out.println("Quack! Quack! Quack!");
		}

	public static void  Display() {
		System.out.println("Oi, eu sou um Pato");
	}
	
	public static void Nadar() {
		System.out.println("Oi, eu Estou nadando!");
		
	}
	public static void Voar() {
		System.out.println("Euuu estouu Voandoo!");
	}
	
	public static void Patao() {
		System.out.println("Eu sou o  Pato!  "
				+ "      	   ########              \r\n" + 
				"                          ######  ####            \r\n" + 
				"                          ######  ############    \r\n" + 
				"                          ##################      \r\n" + 
				"                            ########              \r\n" + 
				"                            ######                \r\n" + 
				"                            ######                \r\n" + 
				"                            ######                \r\n" + 
				"                            ########              \r\n" + 
				"                          ############            \r\n" + 
				"                        ##############            \r\n" + 
				"                      ##################          \r\n" + 
				"          ##############################          \r\n" + 
				"        ################################          \r\n" + 
				"        ################################          \r\n" + 
				"          ############################            \r\n" + 
				"                ####################              \r\n" + 
				"                    ####                          \r\n" + 
				"                    ########             ");
	
	}
}